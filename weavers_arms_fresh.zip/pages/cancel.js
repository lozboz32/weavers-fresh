export default function Cancel(){return <div style={{padding:20}}>Payment cancelled</div>}
