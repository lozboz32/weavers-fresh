export default function Dashboard(){return <div style={{padding:20}}>Admin dashboard (login via Supabase magic link)</div>}
