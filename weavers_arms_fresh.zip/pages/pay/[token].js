export default function Pay(){return <div style={{padding:20}}>Player payment page (token)</div>}
