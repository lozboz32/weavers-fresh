export default function Home(){return <div style={{padding:20}}>Weavers Arms FC — deployed. <a href='/admin/dashboard'>Admin</a></div>}
