export default function Success(){return <div style={{padding:20}}>Payment successful</div>}
